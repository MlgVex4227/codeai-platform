import { View, Text, ScrollView, TouchableOpacity, TextInput, Alert, Platform, KeyboardAvoidingView } from 'react-native';
import { useState, useEffect } from 'react';
import { router, useLocalSearchParams } from 'expo-router';
import { commonStyles } from '../styles/commonStyles';
import Icon from '../components/Icon';
import Button from '../components/Button';
import CodeEditor from '../components/CodeEditor';

export default function EditorScreen() {
  const { projectId } = useLocalSearchParams();
  const [code, setCode] = useState('# Welcome to CodeAI Studio\n# Start typing your code here...\n\nprint("Hello, World!")');
  const [language, setLanguage] = useState('python');
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [fileName, setFileName] = useState('main.py');
  const [showOutput, setShowOutput] = useState(false);

  console.log('EditorScreen rendered with projectId:', projectId);

  useEffect(() => {
    if (projectId) {
      // Load project data
      console.log('Loading project:', projectId);
      // In a real app, this would load from storage
    }
  }, [projectId]);

  const runCode = async () => {
    console.log('Running code:', language);
    setIsRunning(true);
    setShowOutput(true);
    
    try {
      // Simulate code execution
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      if (language === 'python') {
        if (code.includes('print("Hello, World!")')) {
          setOutput('Hello, World!\n\nExecution completed successfully.');
        } else {
          setOutput('Code executed successfully.\n\nNote: This is a demo. Real execution will be implemented with secure sandboxing.');
        }
      } else if (language === 'javascript') {
        setOutput('Code executed successfully.\n\nNote: This is a demo. Real execution will be implemented with secure sandboxing.');
      } else {
        setOutput('Language not yet supported in demo mode.');
      }
    } catch (error) {
      console.error('Code execution error:', error);
      setOutput('Error: Failed to execute code.');
    } finally {
      setIsRunning(false);
    }
  };

  const saveProject = () => {
    console.log('Saving project');
    Alert.alert('Project Saved', 'Your project has been saved successfully!');
  };

  const generateWithAI = () => {
    console.log('Generating code with AI');
    router.push('/ai-assistant?context=editor');
  };

  const languages = [
    { id: 'python', name: 'Python', extension: '.py' },
    { id: 'javascript', name: 'JavaScript', extension: '.js' },
    { id: 'typescript', name: 'TypeScript', extension: '.ts' },
    { id: 'java', name: 'Java', extension: '.java' },
    { id: 'cpp', name: 'C++', extension: '.cpp' },
  ];

  return (
    <KeyboardAvoidingView 
      style={commonStyles.wrapper}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Icon name="arrow-back" size={24} style={styles.headerIcon} />
        </TouchableOpacity>
        
        <View style={styles.headerCenter}>
          <TextInput
            style={styles.fileNameInput}
            value={fileName}
            onChangeText={setFileName}
            placeholder="filename"
            placeholderTextColor="#90CAF9"
          />
        </View>

        <View style={styles.headerActions}>
          <TouchableOpacity onPress={saveProject} style={styles.headerButton}>
            <Icon name="save" size={20} style={styles.headerIcon} />
          </TouchableOpacity>
          <TouchableOpacity onPress={generateWithAI} style={styles.headerButton}>
            <Icon name="sparkles" size={20} style={styles.headerIcon} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Language Selector */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.languageSelector}>
        {languages.map((lang) => (
          <TouchableOpacity
            key={lang.id}
            style={[
              styles.languageTab,
              language === lang.id && styles.languageTabActive
            ]}
            onPress={() => {
              setLanguage(lang.id);
              setFileName(`main${lang.extension}`);
              console.log('Language changed to:', lang.name);
            }}
          >
            <Text style={[
              styles.languageTabText,
              language === lang.id && styles.languageTabTextActive
            ]}>
              {lang.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Code Editor */}
      <View style={styles.editorContainer}>
        <View style={styles.editorHeader}>
          <Text style={styles.editorTitle}>Code Editor</Text>
          <TouchableOpacity onPress={runCode} disabled={isRunning}>
            <View style={[styles.runButton, isRunning && styles.runButtonDisabled]}>
              <Icon 
                name={isRunning ? "hourglass" : "play"} 
                size={16} 
                style={styles.runButtonIcon} 
              />
              <Text style={styles.runButtonText}>
                {isRunning ? 'Running...' : 'Run'}
              </Text>
            </View>
          </TouchableOpacity>
        </View>

        <CodeEditor
          value={code}
          onChangeText={setCode}
          language={language}
          placeholder="Start typing your code..."
          style={styles.codeEditorStyle}
        />
      </View>

      {/* Output Panel */}
      {showOutput && (
        <View style={styles.outputContainer}>
          <View style={styles.outputHeader}>
            <Text style={styles.outputTitle}>Output</Text>
            <TouchableOpacity onPress={() => setShowOutput(false)}>
              <Icon name="close" size={20} style={styles.headerIcon} />
            </TouchableOpacity>
          </View>
          <ScrollView style={styles.outputContent}>
            <Text style={styles.outputText}>{output}</Text>
          </ScrollView>
        </View>
      )}

      {/* Bottom Actions */}
      <View style={styles.bottomActions}>
        <Button
          text="AI Generate"
          onPress={generateWithAI}
          style={styles.actionButton}
        />
        <Button
          text={isRunning ? "Running..." : "Run Code"}
          onPress={runCode}
          style={[styles.actionButton, styles.runActionButton]}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = {
  header: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    justifyContent: 'space-between' as const,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#162133',
    borderBottomWidth: 1,
    borderBottomColor: '#193cb8',
  },
  backButton: {
    padding: 8,
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center' as const,
  },
  fileNameInput: {
    color: '#e3e3e3',
    fontSize: 16,
    fontWeight: '600' as const,
    textAlign: 'center' as const,
    minWidth: 100,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  headerActions: {
    flexDirection: 'row' as const,
    gap: 8,
  },
  headerButton: {
    padding: 8,
  },
  headerIcon: {
    color: '#64B5F6',
  },
  languageSelector: {
    backgroundColor: '#162133',
    borderBottomWidth: 1,
    borderBottomColor: '#193cb8',
  },
  languageTab: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginHorizontal: 4,
  },
  languageTabActive: {
    borderBottomWidth: 2,
    borderBottomColor: '#64B5F6',
  },
  languageTabText: {
    color: '#90CAF9',
    fontSize: 14,
    fontWeight: '500' as const,
  },
  languageTabTextActive: {
    color: '#64B5F6',
    fontWeight: '600' as const,
  },
  editorContainer: {
    flex: 1,
    backgroundColor: '#101824',
  },
  editorHeader: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#162133',
    borderBottomWidth: 1,
    borderBottomColor: '#193cb8',
  },
  editorTitle: {
    color: '#e3e3e3',
    fontSize: 16,
    fontWeight: '600' as const,
  },
  runButton: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    backgroundColor: '#64B5F6',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    gap: 4,
  },
  runButtonDisabled: {
    backgroundColor: '#90CAF9',
    opacity: 0.6,
  },
  runButtonIcon: {
    color: '#101824',
  },
  runButtonText: {
    color: '#101824',
    fontSize: 14,
    fontWeight: '600' as const,
  },
  codeEditorStyle: {
    flex: 1,
  },
  outputContainer: {
    height: 200,
    backgroundColor: '#162133',
    borderTopWidth: 1,
    borderTopColor: '#193cb8',
  },
  outputHeader: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#193cb8',
  },
  outputTitle: {
    color: '#e3e3e3',
    fontSize: 16,
    fontWeight: '600' as const,
  },
  outputContent: {
    flex: 1,
    padding: 16,
  },
  outputText: {
    color: '#e3e3e3',
    fontSize: 14,
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    lineHeight: 20,
  },
  bottomActions: {
    flexDirection: 'row' as const,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#162133',
    borderTopWidth: 1,
    borderTopColor: '#193cb8',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#193cb8',
  },
  runActionButton: {
    backgroundColor: '#64B5F6',
  },
};