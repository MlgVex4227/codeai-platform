import { View, Text, ScrollView, TouchableOpacity, TextInput, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { useState, useEffect, useRef } from 'react';
import { router, useLocalSearchParams } from 'expo-router';
import { commonStyles } from '../styles/commonStyles';
import Icon from '../components/Icon';
import Button from '../components/Button';

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

export default function AIAssistantScreen() {
  const { context } = useLocalSearchParams();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: 'Hello! I\'m your AI coding assistant. I can help you generate code, debug issues, explain concepts, and optimize your programs. What would you like to work on today?',
      timestamp: new Date(),
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);

  console.log('AIAssistantScreen rendered with context:', context);

  const predefinedPrompts = [
    'Create a Python function to calculate fibonacci numbers',
    'Write a React component for a todo list',
    'Generate a sorting algorithm in JavaScript',
    'Create a REST API endpoint in Node.js',
    'Write a SQL query to find duplicate records',
    'Generate a responsive CSS layout',
  ];

  useEffect(() => {
    // Auto-scroll to bottom when new messages are added
    if (scrollViewRef.current) {
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [messages]);

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;

    console.log('Sending message:', text);
    
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: text,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsGenerating(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(text);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: aiResponse,
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsGenerating(false);
    }, 2000);
  };

  const generateAIResponse = (prompt: string): string => {
    console.log('Generating AI response for:', prompt);
    
    if (prompt.toLowerCase().includes('fibonacci')) {
      return `Here's a Python function to calculate Fibonacci numbers:

\`\`\`python
def fibonacci(n):
    """Calculate the nth Fibonacci number."""
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Optimized version with memoization
def fibonacci_memo(n, memo={}):
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    memo[n] = fibonacci_memo(n-1, memo) + fibonacci_memo(n-2, memo)
    return memo[n]

# Example usage
print(fibonacci_memo(10))  # Output: 55
\`\`\`

This implementation includes both a basic recursive version and an optimized version using memoization for better performance.`;
    }
    
    if (prompt.toLowerCase().includes('react') && prompt.toLowerCase().includes('todo')) {
      return `Here's a React component for a todo list:

\`\`\`jsx
import React, { useState } from 'react';

function TodoList() {
  const [todos, setTodos] = useState([]);
  const [inputValue, setInputValue] = useState('');

  const addTodo = () => {
    if (inputValue.trim()) {
      setTodos([...todos, {
        id: Date.now(),
        text: inputValue,
        completed: false
      }]);
      setInputValue('');
    }
  };

  const toggleTodo = (id) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  return (
    <div className="todo-list">
      <h2>Todo List</h2>
      <div className="input-section">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Add a new todo..."
          onKeyPress={(e) => e.key === 'Enter' && addTodo()}
        />
        <button onClick={addTodo}>Add</button>
      </div>
      <ul>
        {todos.map(todo => (
          <li key={todo.id} className={todo.completed ? 'completed' : ''}>
            <span onClick={() => toggleTodo(todo.id)}>{todo.text}</span>
            <button onClick={() => deleteTodo(todo.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TodoList;
\`\`\`

This component includes add, toggle, and delete functionality with a clean interface.`;
    }

    return `I understand you're asking about: "${prompt}"

This is a demo version of the AI assistant. In the full implementation, I would:

1. **Analyze your request** using advanced language models
2. **Generate relevant code** based on your specific requirements
3. **Provide explanations** and best practices
4. **Suggest optimizations** and alternatives

For now, try asking about:
- Fibonacci numbers
- React todo components
- Sorting algorithms
- API endpoints
- Database queries

The AI assistant will be powered by OpenAI's GPT models in the production version, providing intelligent code generation and programming assistance.`;
  };

  const usePredefinedPrompt = (prompt: string) => {
    console.log('Using predefined prompt:', prompt);
    sendMessage(prompt);
  };

  const copyToClipboard = (text: string) => {
    console.log('Copying to clipboard:', text.substring(0, 50) + '...');
    Alert.alert('Copied!', 'Code has been copied to clipboard');
  };

  return (
    <KeyboardAvoidingView 
      style={commonStyles.wrapper}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Icon name="arrow-back" size={24} style={styles.headerIcon} />
        </TouchableOpacity>
        
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>AI Assistant</Text>
        </View>

        <TouchableOpacity onPress={() => setMessages([messages[0]])} style={styles.headerButton}>
          <Icon name="refresh" size={20} style={styles.headerIcon} />
        </TouchableOpacity>
      </View>

      {/* Messages */}
      <ScrollView 
        ref={scrollViewRef}
        style={styles.messagesContainer} 
        contentContainerStyle={styles.messagesContent}
        keyboardShouldPersistTaps="handled"
      >
        {messages.map((message) => (
          <View key={message.id} style={[
            styles.messageContainer,
            message.type === 'user' ? styles.userMessage : styles.aiMessage
          ]}>
            <View style={styles.messageHeader}>
              <Icon 
                name={message.type === 'user' ? 'person' : 'sparkles'} 
                size={16} 
                style={styles.messageIcon} 
              />
              <Text style={styles.messageAuthor}>
                {message.type === 'user' ? 'You' : 'AI Assistant'}
              </Text>
            </View>
            <Text style={styles.messageContent}>{message.content}</Text>
            {message.type === 'ai' && message.content.includes('```') && (
              <TouchableOpacity 
                style={styles.copyButton}
                onPress={() => copyToClipboard(message.content)}
              >
                <Icon name="copy" size={16} style={styles.copyIcon} />
                <Text style={styles.copyText}>Copy Code</Text>
              </TouchableOpacity>
            )}
          </View>
        ))}
        
        {isGenerating && (
          <View style={[styles.messageContainer, styles.aiMessage]}>
            <View style={styles.messageHeader}>
              <Icon name="sparkles" size={16} style={styles.messageIcon} />
              <Text style={styles.messageAuthor}>AI Assistant</Text>
            </View>
            <Text style={styles.loadingText}>Generating response...</Text>
          </View>
        )}
      </ScrollView>

      {/* Predefined Prompts */}
      {messages.length === 1 && (
        <View style={styles.promptsContainer}>
          <Text style={styles.promptsTitle}>Try these prompts:</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {predefinedPrompts.map((prompt, index) => (
              <TouchableOpacity
                key={index}
                style={styles.promptChip}
                onPress={() => usePredefinedPrompt(prompt)}
              >
                <Text style={styles.promptText}>{prompt}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}

      {/* Input */}
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          value={inputText}
          onChangeText={setInputText}
          placeholder="Ask me to generate code, explain concepts, or help debug..."
          placeholderTextColor="#90CAF9"
          multiline
          maxLength={500}
          returnKeyType="send"
          onSubmitEditing={() => sendMessage(inputText)}
          blurOnSubmit={false}
        />
        <TouchableOpacity
          style={[styles.sendButton, !inputText.trim() && styles.sendButtonDisabled]}
          onPress={() => sendMessage(inputText)}
          disabled={!inputText.trim() || isGenerating}
        >
          <Icon name="send" size={20} style={styles.sendIcon} />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = {
  header: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    justifyContent: 'space-between' as const,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#162133',
    borderBottomWidth: 1,
    borderBottomColor: '#193cb8',
  },
  backButton: {
    padding: 8,
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center' as const,
  },
  headerTitle: {
    color: '#e3e3e3',
    fontSize: 18,
    fontWeight: '600' as const,
  },
  headerButton: {
    padding: 8,
  },
  headerIcon: {
    color: '#64B5F6',
  },
  messagesContainer: {
    flex: 1,
    backgroundColor: '#101824',
  },
  messagesContent: {
    padding: 16,
    paddingBottom: 20,
  },
  messageContainer: {
    marginBottom: 16,
    padding: 12,
    borderRadius: 12,
    maxWidth: '85%',
  },
  userMessage: {
    backgroundColor: '#193cb8',
    alignSelf: 'flex-end' as const,
  },
  aiMessage: {
    backgroundColor: '#162133',
    alignSelf: 'flex-start' as const,
    borderWidth: 1,
    borderColor: '#193cb8',
  },
  messageHeader: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    marginBottom: 8,
  },
  messageIcon: {
    color: '#64B5F6',
    marginRight: 8,
  },
  messageAuthor: {
    color: '#64B5F6',
    fontSize: 12,
    fontWeight: '600' as const,
  },
  messageContent: {
    color: '#e3e3e3',
    fontSize: 14,
    lineHeight: 20,
  },
  loadingText: {
    color: '#90CAF9',
    fontSize: 14,
    fontStyle: 'italic' as const,
  },
  copyButton: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    marginTop: 8,
    paddingVertical: 4,
  },
  copyIcon: {
    color: '#64B5F6',
    marginRight: 4,
  },
  copyText: {
    color: '#64B5F6',
    fontSize: 12,
    fontWeight: '500' as const,
  },
  promptsContainer: {
    padding: 16,
    backgroundColor: '#162133',
    borderTopWidth: 1,
    borderTopColor: '#193cb8',
  },
  promptsTitle: {
    color: '#e3e3e3',
    fontSize: 14,
    fontWeight: '600' as const,
    marginBottom: 12,
  },
  promptChip: {
    backgroundColor: '#101824',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#193cb8',
  },
  promptText: {
    color: '#64B5F6',
    fontSize: 12,
    fontWeight: '500' as const,
  },
  inputContainer: {
    flexDirection: 'row' as const,
    alignItems: 'flex-end' as const,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#162133',
    borderTopWidth: 1,
    borderTopColor: '#193cb8',
  },
  textInput: {
    flex: 1,
    backgroundColor: '#101824',
    color: '#e3e3e3',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginRight: 12,
    maxHeight: 100,
    borderWidth: 1,
    borderColor: '#193cb8',
  },
  sendButton: {
    backgroundColor: '#64B5F6',
    borderRadius: 20,
    padding: 12,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  },
  sendButtonDisabled: {
    backgroundColor: '#90CAF9',
    opacity: 0.5,
  },
  sendIcon: {
    color: '#101824',
  },
};