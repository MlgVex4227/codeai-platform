import { View, Text, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import { router } from 'expo-router';
import { commonStyles } from '../styles/commonStyles';
import Icon from '../components/Icon';
import Button from '../components/Button';

interface Project {
  id: string;
  name: string;
  language: string;
  description: string;
  lastModified: string;
  fileCount: number;
  size: string;
}

export default function ProjectsScreen() {
  const [projects, setProjects] = useState<Project[]>([
    {
      id: '1',
      name: 'Python Calculator',
      language: 'python',
      description: 'A scientific calculator with advanced functions',
      lastModified: '2 hours ago',
      fileCount: 3,
      size: '2.4 KB',
    },
    {
      id: '2',
      name: 'React Component Library',
      language: 'javascript',
      description: 'Reusable UI components for React applications',
      lastModified: '1 day ago',
      fileCount: 12,
      size: '45.2 KB',
    },
    {
      id: '3',
      name: 'Data Analysis Script',
      language: 'python',
      description: 'Pandas and NumPy data processing pipeline',
      lastModified: '3 days ago',
      fileCount: 5,
      size: '8.7 KB',
    },
    {
      id: '4',
      name: 'REST API Server',
      language: 'javascript',
      description: 'Node.js Express server with authentication',
      lastModified: '1 week ago',
      fileCount: 8,
      size: '23.1 KB',
    },
    {
      id: '5',
      name: 'Machine Learning Model',
      language: 'python',
      description: 'TensorFlow image classification model',
      lastModified: '2 weeks ago',
      fileCount: 7,
      size: '156.8 KB',
    },
  ]);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('all');

  console.log('ProjectsScreen rendered with', projects.length, 'projects');

  const languages = ['all', 'python', 'javascript', 'typescript', 'java', 'cpp'];

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLanguage = selectedLanguage === 'all' || project.language === selectedLanguage;
    return matchesSearch && matchesLanguage;
  });

  const openProject = (projectId: string) => {
    console.log('Opening project:', projectId);
    router.push(`/editor?projectId=${projectId}`);
  };

  const createNewProject = () => {
    console.log('Creating new project');
    router.push('/editor');
  };

  const deleteProject = (projectId: string) => {
    console.log('Deleting project:', projectId);
    Alert.alert(
      'Delete Project',
      'Are you sure you want to delete this project? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            setProjects(prev => prev.filter(p => p.id !== projectId));
            Alert.alert('Project Deleted', 'The project has been deleted successfully.');
          },
        },
      ]
    );
  };

  const getLanguageIcon = (language: string) => {
    switch (language) {
      case 'python': return 'logo-python';
      case 'javascript': return 'logo-javascript';
      case 'typescript': return 'logo-javascript';
      case 'java': return 'code-slash';
      case 'cpp': return 'code-slash';
      default: return 'document';
    }
  };

  return (
    <View style={commonStyles.wrapper}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Icon name="arrow-back" size={24} style={styles.headerIcon} />
        </TouchableOpacity>
        
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>My Projects</Text>
        </View>

        <TouchableOpacity onPress={createNewProject} style={styles.headerButton}>
          <Icon name="add" size={24} style={styles.headerIcon} />
        </TouchableOpacity>
      </View>

      {/* Search and Filter */}
      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Icon name="search" size={20} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Search projects..."
            placeholderTextColor="#90CAF9"
          />
        </View>
      </View>

      {/* Language Filter */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.languageFilter}>
        {languages.map((lang) => (
          <TouchableOpacity
            key={lang}
            style={[
              styles.languageChip,
              selectedLanguage === lang && styles.languageChipActive
            ]}
            onPress={() => {
              setSelectedLanguage(lang);
              console.log('Language filter changed to:', lang);
            }}
          >
            <Text style={[
              styles.languageChipText,
              selectedLanguage === lang && styles.languageChipTextActive
            ]}>
              {lang === 'all' ? 'All' : lang.charAt(0).toUpperCase() + lang.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Projects List */}
      <ScrollView style={styles.projectsList} contentContainerStyle={styles.projectsContent}>
        {filteredProjects.length === 0 ? (
          <View style={styles.emptyState}>
            <Icon name="folder-open" size={64} style={styles.emptyIcon} />
            <Text style={styles.emptyTitle}>No Projects Found</Text>
            <Text style={styles.emptySubtitle}>
              {searchQuery ? 'Try adjusting your search terms' : 'Create your first project to get started'}
            </Text>
            <Button
              text="Create New Project"
              onPress={createNewProject}
              style={styles.emptyButton}
            />
          </View>
        ) : (
          filteredProjects.map((project) => (
            <TouchableOpacity
              key={project.id}
              style={styles.projectCard}
              onPress={() => openProject(project.id)}
              activeOpacity={0.8}
            >
              <View style={styles.projectHeader}>
                <View style={styles.projectInfo}>
                  <Icon 
                    name={getLanguageIcon(project.language)} 
                    size={24} 
                    style={styles.projectIcon} 
                  />
                  <View style={styles.projectDetails}>
                    <Text style={styles.projectName}>{project.name}</Text>
                    <Text style={styles.projectDescription}>{project.description}</Text>
                  </View>
                </View>
                <TouchableOpacity
                  style={styles.deleteButton}
                  onPress={() => deleteProject(project.id)}
                >
                  <Icon name="trash" size={20} style={styles.deleteIcon} />
                </TouchableOpacity>
              </View>
              
              <View style={styles.projectMeta}>
                <View style={styles.metaItem}>
                  <Icon name="time" size={14} style={styles.metaIcon} />
                  <Text style={styles.metaText}>{project.lastModified}</Text>
                </View>
                <View style={styles.metaItem}>
                  <Icon name="document" size={14} style={styles.metaIcon} />
                  <Text style={styles.metaText}>{project.fileCount} files</Text>
                </View>
                <View style={styles.metaItem}>
                  <Icon name="archive" size={14} style={styles.metaIcon} />
                  <Text style={styles.metaText}>{project.size}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>

      {/* Floating Action Button */}
      <TouchableOpacity style={styles.fab} onPress={createNewProject}>
        <Icon name="add" size={24} style={styles.fabIcon} />
      </TouchableOpacity>
    </View>
  );
}

const styles = {
  header: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    justifyContent: 'space-between' as const,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#162133',
    borderBottomWidth: 1,
    borderBottomColor: '#193cb8',
  },
  backButton: {
    padding: 8,
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center' as const,
  },
  headerTitle: {
    color: '#e3e3e3',
    fontSize: 18,
    fontWeight: '600' as const,
  },
  headerButton: {
    padding: 8,
  },
  headerIcon: {
    color: '#64B5F6',
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#162133',
    borderBottomWidth: 1,
    borderBottomColor: '#193cb8',
  },
  searchInputContainer: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    backgroundColor: '#101824',
    borderRadius: 12,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: '#193cb8',
  },
  searchIcon: {
    color: '#90CAF9',
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    color: '#e3e3e3',
    fontSize: 16,
    paddingVertical: 12,
  },
  languageFilter: {
    backgroundColor: '#162133',
    borderBottomWidth: 1,
    borderBottomColor: '#193cb8',
    paddingVertical: 8,
  },
  languageChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginHorizontal: 4,
    borderRadius: 16,
    backgroundColor: '#101824',
    borderWidth: 1,
    borderColor: '#193cb8',
  },
  languageChipActive: {
    backgroundColor: '#64B5F6',
    borderColor: '#64B5F6',
  },
  languageChipText: {
    color: '#90CAF9',
    fontSize: 14,
    fontWeight: '500' as const,
  },
  languageChipTextActive: {
    color: '#101824',
    fontWeight: '600' as const,
  },
  projectsList: {
    flex: 1,
    backgroundColor: '#101824',
  },
  projectsContent: {
    padding: 16,
  },
  projectCard: {
    backgroundColor: '#162133',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#193cb8',
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.2)',
    elevation: 2,
  },
  projectHeader: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'flex-start' as const,
    marginBottom: 12,
  },
  projectInfo: {
    flexDirection: 'row' as const,
    alignItems: 'flex-start' as const,
    flex: 1,
  },
  projectIcon: {
    color: '#64B5F6',
    marginRight: 12,
    marginTop: 2,
  },
  projectDetails: {
    flex: 1,
  },
  projectName: {
    fontSize: 16,
    fontWeight: '600' as const,
    color: '#e3e3e3',
    marginBottom: 4,
  },
  projectDescription: {
    fontSize: 14,
    color: '#90CAF9',
    lineHeight: 20,
  },
  deleteButton: {
    padding: 4,
  },
  deleteIcon: {
    color: '#ff6b6b',
  },
  projectMeta: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
  },
  metaItem: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
  },
  metaIcon: {
    color: '#90CAF9',
    marginRight: 4,
  },
  metaText: {
    fontSize: 12,
    color: '#90CAF9',
  },
  emptyState: {
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    paddingVertical: 60,
  },
  emptyIcon: {
    color: '#90CAF9',
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600' as const,
    color: '#e3e3e3',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#90CAF9',
    textAlign: 'center' as const,
    marginBottom: 24,
    lineHeight: 20,
  },
  emptyButton: {
    backgroundColor: '#64B5F6',
    paddingHorizontal: 24,
  },
  fab: {
    position: 'absolute' as const,
    bottom: 24,
    right: 24,
    backgroundColor: '#64B5F6',
    borderRadius: 28,
    width: 56,
    height: 56,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
  },
  fabIcon: {
    color: '#101824',
  },
};