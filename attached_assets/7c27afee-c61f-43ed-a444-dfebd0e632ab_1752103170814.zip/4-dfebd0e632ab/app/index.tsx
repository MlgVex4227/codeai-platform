import { Text, View, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { router } from 'expo-router';
import { useState, useEffect } from 'react';
import { commonStyles } from '../styles/commonStyles';
import Icon from '../components/Icon';
import { LinearGradient } from 'expo-linear-gradient';

export default function MainScreen() {
  const [recentProjects, setRecentProjects] = useState([
    { id: '1', name: 'Python Calculator', language: 'python', lastModified: '2 hours ago' },
    { id: '2', name: 'React Component', language: 'javascript', lastModified: '1 day ago' },
    { id: '3', name: 'Data Analysis', language: 'python', lastModified: '3 days ago' },
  ]);

  console.log('MainScreen rendered with recent projects:', recentProjects.length);

  const navigateToEditor = (projectId?: string) => {
    console.log('Navigating to editor with project:', projectId);
    if (projectId) {
      router.push(`/editor?projectId=${projectId}`);
    } else {
      router.push('/editor');
    }
  };

  const navigateToProjects = () => {
    console.log('Navigating to projects');
    router.push('/projects');
  };

  const navigateToAI = () => {
    console.log('Navigating to AI assistant');
    router.push('/ai-assistant');
  };

  return (
    <ScrollView style={commonStyles.wrapper} contentContainerStyle={{ flexGrow: 1 }}>
      <LinearGradient
        colors={['#101824', '#162133']}
        style={commonStyles.container}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>CodeAI Studio</Text>
          <Text style={styles.headerSubtitle}>Your Personal Coding Assistant</Text>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionGrid}>
            <TouchableOpacity 
              style={styles.actionCard} 
              onPress={() => navigateToEditor()}
              activeOpacity={0.8}
            >
              <Icon name="code-slash" size={32} style={styles.actionIcon} />
              <Text style={styles.actionTitle}>New Project</Text>
              <Text style={styles.actionSubtitle}>Start coding</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.actionCard} 
              onPress={navigateToAI}
              activeOpacity={0.8}
            >
              <Icon name="sparkles" size={32} style={styles.actionIcon} />
              <Text style={styles.actionTitle}>AI Assistant</Text>
              <Text style={styles.actionSubtitle}>Generate code</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.actionCard} 
              onPress={navigateToProjects}
              activeOpacity={0.8}
            >
              <Icon name="folder" size={32} style={styles.actionIcon} />
              <Text style={styles.actionTitle}>My Projects</Text>
              <Text style={styles.actionSubtitle}>Browse files</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.actionCard} 
              onPress={() => Alert.alert('Coming Soon', 'Terminal feature will be available soon!')}
              activeOpacity={0.8}
            >
              <Icon name="terminal" size={32} style={styles.actionIcon} />
              <Text style={styles.actionTitle}>Terminal</Text>
              <Text style={styles.actionSubtitle}>Run commands</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Recent Projects */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Projects</Text>
            <TouchableOpacity onPress={navigateToProjects}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          {recentProjects.map((project) => (
            <TouchableOpacity 
              key={project.id}
              style={styles.projectCard}
              onPress={() => navigateToEditor(project.id)}
              activeOpacity={0.8}
            >
              <View style={styles.projectInfo}>
                <Icon 
                  name={project.language === 'python' ? 'logo-python' : 'logo-javascript'} 
                  size={24} 
                  style={styles.projectIcon} 
                />
                <View style={styles.projectDetails}>
                  <Text style={styles.projectName}>{project.name}</Text>
                  <Text style={styles.projectMeta}>{project.language} • {project.lastModified}</Text>
                </View>
              </View>
              <Icon name="chevron-forward" size={20} style={styles.chevronIcon} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Features */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Features</Text>
          <View style={styles.featureList}>
            <View style={styles.featureItem}>
              <Icon name="checkmark-circle" size={20} style={styles.featureIcon} />
              <Text style={styles.featureText}>AI-powered code generation</Text>
            </View>
            <View style={styles.featureItem}>
              <Icon name="checkmark-circle" size={20} style={styles.featureIcon} />
              <Text style={styles.featureText}>Multi-language support</Text>
            </View>
            <View style={styles.featureItem}>
              <Icon name="checkmark-circle" size={20} style={styles.featureIcon} />
              <Text style={styles.featureText}>Secure code execution</Text>
            </View>
            <View style={styles.featureItem}>
              <Icon name="checkmark-circle" size={20} style={styles.featureIcon} />
              <Text style={styles.featureText}>Project management</Text>
            </View>
          </View>
        </View>
      </LinearGradient>
    </ScrollView>
  );
}

const styles = {
  header: {
    alignItems: 'center' as const,
    paddingVertical: 40,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: '800' as const,
    color: '#e3e3e3',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#90CAF9',
    textAlign: 'center' as const,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  sectionHeader: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700' as const,
    color: '#e3e3e3',
    marginBottom: 16,
  },
  seeAllText: {
    fontSize: 14,
    color: '#64B5F6',
    fontWeight: '600' as const,
  },
  actionGrid: {
    flexDirection: 'row' as const,
    flexWrap: 'wrap' as const,
    justifyContent: 'space-between' as const,
  },
  actionCard: {
    backgroundColor: '#162133',
    borderRadius: 12,
    padding: 20,
    width: '48%',
    marginBottom: 12,
    alignItems: 'center' as const,
    borderWidth: 1,
    borderColor: '#193cb8',
    boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.3)',
    elevation: 4,
  },
  actionIcon: {
    color: '#64B5F6',
    marginBottom: 8,
  },
  actionTitle: {
    fontSize: 14,
    fontWeight: '600' as const,
    color: '#e3e3e3',
    marginBottom: 4,
    textAlign: 'center' as const,
  },
  actionSubtitle: {
    fontSize: 12,
    color: '#90CAF9',
    textAlign: 'center' as const,
  },
  projectCard: {
    backgroundColor: '#162133',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    justifyContent: 'space-between' as const,
    borderWidth: 1,
    borderColor: '#193cb8',
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.2)',
    elevation: 2,
  },
  projectInfo: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    flex: 1,
  },
  projectIcon: {
    color: '#64B5F6',
    marginRight: 12,
  },
  projectDetails: {
    flex: 1,
  },
  projectName: {
    fontSize: 16,
    fontWeight: '600' as const,
    color: '#e3e3e3',
    marginBottom: 4,
  },
  projectMeta: {
    fontSize: 12,
    color: '#90CAF9',
  },
  chevronIcon: {
    color: '#90CAF9',
  },
  featureList: {
    gap: 12,
  },
  featureItem: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
  },
  featureIcon: {
    color: '#64B5F6',
    marginRight: 12,
  },
  featureText: {
    fontSize: 14,
    color: '#e3e3e3',
    fontWeight: '500' as const,
  },
};