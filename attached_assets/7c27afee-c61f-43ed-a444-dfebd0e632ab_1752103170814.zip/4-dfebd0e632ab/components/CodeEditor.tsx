import { View, TextInput, ScrollView, Text, Platform, KeyboardAvoidingView } from 'react-native';
import { useState, useEffect, useRef } from 'react';
import { commonStyles, colors } from '../styles/commonStyles';

interface CodeEditorProps {
  value: string;
  onChangeText: (text: string) => void;
  language?: string;
  placeholder?: string;
  style?: any;
}

export default function CodeEditor({ 
  value, 
  onChangeText, 
  language = 'javascript', 
  placeholder = 'Start typing your code...',
  style 
}: CodeEditorProps) {
  const [lineNumbers, setLineNumbers] = useState<string[]>([]);
  const scrollViewRef = useRef<ScrollView>(null);
  const textInputRef = useRef<TextInput>(null);

  console.log('CodeEditor rendered for language:', language, 'at', new Date().toISOString());

  useEffect(() => {
    const lines = value.split('\n');
    const numbers = lines.map((_, index) => (index + 1).toString().padStart(2, ' '));
    setLineNumbers(numbers);
  }, [value]);

  const getLanguageColor = (lang: string) => {
    switch (lang) {
      case 'python': return '#3776ab';
      case 'javascript': return '#f7df1e';
      case 'typescript': return '#3178c6';
      case 'java': return '#ed8b00';
      case 'cpp': return '#00599c';
      default: return colors.accent;
    }
  };

  const handleTextChange = (text: string) => {
    onChangeText(text);
  };

  const handleContentSizeChange = () => {
    // Auto-scroll to bottom when content changes (optional)
    if (scrollViewRef.current) {
      scrollViewRef.current.scrollToEnd({ animated: false });
    }
  };

  return (
    <KeyboardAvoidingView 
      style={[styles.container, style]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      {/* Language indicator */}
      <View style={styles.languageBar}>
        <View style={[styles.languageIndicator, { backgroundColor: getLanguageColor(language) }]} />
        <Text style={styles.languageText}>{language.toUpperCase()}</Text>
      </View>

      {/* Editor */}
      <View style={styles.editorContainer}>
        {/* Line numbers */}
        <ScrollView 
          ref={scrollViewRef}
          style={styles.lineNumbers} 
          showsVerticalScrollIndicator={false}
          scrollEnabled={false}
        >
          {lineNumbers.map((number, index) => (
            <Text key={index} style={styles.lineNumber}>
              {number}
            </Text>
          ))}
        </ScrollView>

        {/* Code input */}
        <View style={styles.codeInputContainer}>
          <TextInput
            ref={textInputRef}
            style={styles.codeInput}
            value={value}
            onChangeText={handleTextChange}
            onContentSizeChange={handleContentSizeChange}
            multiline
            placeholder={placeholder}
            placeholderTextColor="#6e7681"
            textAlignVertical="top"
            scrollEnabled={true}
            autoCapitalize="none"
            autoCorrect={false}
            spellCheck={false}
            keyboardType="default"
            returnKeyType="default"
            blurOnSubmit={false}
            selectTextOnFocus={false}
            dataDetectorTypes="none"
          />
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = {
  container: {
    flex: 1,
    backgroundColor: '#0d1117',
    borderRadius: 8,
    overflow: 'hidden' as const,
  },
  languageBar: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#161b22',
    borderBottomWidth: 1,
    borderBottomColor: '#21262d',
  },
  languageIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  languageText: {
    color: '#8b949e',
    fontSize: 12,
    fontWeight: '500' as const,
  },
  editorContainer: {
    flex: 1,
    flexDirection: 'row' as const,
  },
  lineNumbers: {
    backgroundColor: '#0d1117',
    paddingHorizontal: 8,
    paddingVertical: 16,
    borderRightWidth: 1,
    borderRightColor: '#21262d',
    minWidth: 40,
    maxWidth: 50,
  },
  lineNumber: {
    color: '#6e7681',
    fontSize: 14,
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    lineHeight: 20,
    textAlign: 'right' as const,
  },
  codeInputContainer: {
    flex: 1,
    position: 'relative' as const,
  },
  codeInput: {
    flex: 1,
    backgroundColor: '#0d1117',
    color: '#e6edf3',
    padding: 16,
    fontSize: 14,
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    lineHeight: 20,
    textAlignVertical: 'top' as const,
    minHeight: 200,
  },
};